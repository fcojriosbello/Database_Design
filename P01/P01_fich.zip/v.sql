-- Table: v
DROP TABLE v CASCADE;
CREATE TABLE v (
  v_ID CHAR(4) PRIMARY KEY,
  n_v VARCHAR (20),
  p_v VARCHAR (30)
);
