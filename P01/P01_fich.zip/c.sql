-- Table: c
DROP TABLE c CASCADE;
CREATE TABLE c (
  c_ID CHAR(4) PRIMARY KEY,
  n_c CHAR (20),
  p_c CHAR (30)
);
