-- Table: e
DROP TABLE e CASCADE;
CREATE TABLE e (
  e_ID CHAR(4) PRIMARY KEY,
  n_e VARCHAR (20),
  p_e VARCHAR (30),
  t_e VARCHAR (25)
);



